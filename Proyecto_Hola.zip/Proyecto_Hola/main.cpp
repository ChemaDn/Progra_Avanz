#include <cstdlib>
#include <iostream>

using namespace std;//cin,cout,endl
#define ARCHIVO_TXT c:/Users/Sala5/archivo.txt//respaldo de datos

int main()
{
    cout<<"Hola mundo C++ curso Programacion Avanzada"<<endl;
    system("PAUSE");
    return 0;
}
